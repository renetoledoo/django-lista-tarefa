from django.db import models

# Create your models here.


class Tarefas(models.Model):
    id = models.CharField(max_length=50, primary_key=True) 
    titulo = models.CharField(("nome"), max_length=250)
    prioridade = models.CharField(("prioridade"), max_length=1)
    area = models.CharField(("area"), max_length=50)
    status = models.CharField(("status"), max_length=50)
    
    